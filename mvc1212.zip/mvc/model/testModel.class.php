<?php
/**
 * student表的操作类，继承基础模型类
 */
require_once 'item.class.php';
class testModel {

	public $id;
	public $name;
	public $gender;
	public $age;

}
